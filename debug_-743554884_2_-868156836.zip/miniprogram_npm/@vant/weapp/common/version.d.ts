export declare function canIUseModel(): boolean;
export declare function canIUseFormFieldButton(): boolean;
