var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/http"));

Page({
    data: {
        sureresult: [],
        result: [],
        list: [],
        Number: "",
        Name: "",
        company: "",
        name: "",
        phone: "",
        listarr: [],
        show: !1,
        searchbox: "",
        IsDisplay: 0
    },
    showpopu: function() {
        this.setData({
            show: !0
        });
    },
    Selectself: function(t) {
        this.setData({
            IsDisplay: t.detail.value
        });
    },
    Select: function(t) {
        this.setData({
            type: t.detail.value
        });
    },
    sureresult: function() {
        var t = this.data.result, e = this.data.list.filter(function(e) {
            if (console.log(t, e.Id, t.indexOf(e.Id)), -1 != t.indexOf(e.Id.toString())) return e.checked = !0, 
            e;
            e.checked = !1;
        });
        this.setData({
            sureresult: this.data.result,
            show: !1,
            listarr: e
        });
    },
    onClose: function() {
        var t = this.data.sureresult, e = this.data.list.map(function(e) {
            return -1 != t.indexOf(e.Id.toString()) ? e.checked = !0 : e.checked = !1, e;
        });
        console.log(e), this.setData({
            show: !1,
            list: e,
            result: t
        });
    },
    onChange: function(t) {
        this.setData({
            result: t.detail
        });
    },
    getlist: function() {
        var e = this, s = "/AppletEquipment/GetList?search=" + this.data.searchbox;
        t.default.getReq(s, function(t) {
            0 == t.code && e.setData({
                list: t.list
            });
        });
    },
    onChangeinp: function() {
        this.getlist();
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getlist();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    addsub: function() {
        console.log(this.data.result);
        var e = this.data.sureresult.join(","), s = this.data;
        if (!s.Number) return wx.showToast({
            title: "请填写一体机编号",
            icon: "none"
        }), !1;
        if (!s.Name) return wx.showToast({
            title: "请填写一体机名称",
            icon: "none"
        }), !1;
        if (!e) return wx.showToast({
            title: "请添加地磅",
            icon: "none"
        }), !1;
        wx.getStorageSync("user").openId, wx.getStorageSync("user").usermodel.TypeId;
        var n = "/AppletAIO/Create?Number=" + s.Number + "&Name=" + s.Name + "&WeighbridgeId=" + e;
        t.default.getReq(n, function(t) {
            console.log(t), 0 == t.code ? (wx.showToast({
                title: t.msg
            }), wx.navigateBack({
                delta: 1
            })) : wx.showToast({
                title: t.msg,
                icon:'none'
            });
        });
    }
});