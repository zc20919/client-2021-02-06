var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        maxNumber: 100,
        number: 0,
        fileList: [],
        typeId: 0,
        reviewText: ""
    },
    delete: function(t) {
        console.log(t);
        var e = this.data.fileList;
        e.splice(t.detail.index, 1), this.setData({
            fileList: e
        });
    },
    afterRead: function(t) {
        var e = this, i = t.detail.file;
        wx.uploadFile({
            url: "https://weighbridge.wxpaying.com/AppletUploadPic/Index",
            filePath: i.path,
            name: "file",
            formData: {
                user: "test"
            },
            success: function(t) {
                var i = JSON.parse(t.data);
                if (console.log(i), 0 == i.code) {
                    wx.showToast({
                        title: i.msg
                    });
                    var n = e.data.fileList;
                    n.push(i), e.setData({
                        fileList: n
                    });
                }
            }
        });
    },
    inputText: function(t) {
        var e = t.detail.value, i = e.length;
        this.setData({
            number: i,
            reviewText: e
        });
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    sunmitidea: function() {
        if (!this.data.reviewText) return wx.showToast({
            title: "请填写意见"
        }), !1;
        var e = wx.getStorageSync("user").openId, i = this.data.fileList.map(function(t) {
            return t.url;
        }).join(","), n = "/AppletMyCenter/Feedback?typeId=0&openId=" + e + "&content=" + this.data.reviewText + "&imagelist=" + i;
        t.default.getReq(n, function(t) {
            0 == t.code ? wx.showToast({
                title: "提交成功",
                duration: 1e3,
                success: function(t) {
                    setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 1e3);
                }
            }) : wx.showToast({
                title: t.msg,
                duration: 1e3
            });
        });
    }
});