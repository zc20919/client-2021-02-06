var n = function(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}(require("../../utils/http"));

Page({
    data: {
        navlist: [ "综合", "价格", "销量" ],
        list: [],
        navindex: null
    },
    onLoad: function(n) {},
    changenav: function(t) {
        var e = this;
        console.log(t.currentTarget.dataset.index), this.data.navindex == t.currentTarget.dataset.index ? this.setData({
            navindex: null
        }) : this.setData({
            navindex: t.currentTarget.dataset.index
        });
        var a = "/AppletGoods/Index?synthesize=" + (0 == this.data.navindex ? 1 : 0) + "&&money=" + (1 == this.data.navindex ? 1 : 0) + "&&sales=" + (2 == this.data.navindex ? 1 : 0);
        n.default.getReq(a, function(n) {
            console.log(n.code, 12323211), 200 != n.code && 0 != n.code || e.setData({
                list: n.list
            });
        });
    },
    gonav: function(n) {
        wx.navigateTo({
            url: n.currentTarget.dataset.url
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        n.default.getReq("/AppletGoods/Index?synthesize=0&&money=0&&sales=0", function(n) {
            console.log(n.code, 12323211), 200 != n.code && 0 != n.code || t.setData({
                list: n.list
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});