var n = function(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}(require("../../utils/http"));

Page({
    data: {
        list: [],
        search:''
    },
    onLoad: function(n) {},
    gonav: function(n) {
        console.log(n), wx.navigateTo({
            url: n.currentTarget.dataset.url
        });
    },
    onReady: function() {},
    getlist(){
        var t = this, e = "/NetWeightQuery/GetWeighbridgeList?openId=" + wx.getStorageSync("user").openId+"&search="+this.data.search;
        n.default.getReq(e, function(n) {
            0 == n.code && t.setData({
                list: n.list
            });
        });
    },
    onShow: function() {
      this.getlist()
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});