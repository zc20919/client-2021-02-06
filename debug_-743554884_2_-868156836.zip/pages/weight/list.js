var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        search: "",
        onlineCount: "",
        totalCount: ""
    },
    goadd: function() {
        wx.navigateTo({
            url: "/pages/weight/add"
        });
    },
    edit(e){
        wx.navigateTo({
            url: "/pages/weight/add?id="+e.currentTarget.dataset.id
        });
        // e.currentTarget.dataset.id
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getlist();
    },
    del(e){
        var n = this, e = "/Delete/Index?TypeId=1&Id=" +e.currentTarget.dataset.id;
        wx.showModal({
            title: '是否删除',
            content: '请确认删除地磅',
            cancelText:"否",//默认是“取消”
            confirmText:"是",//默认是“确定”
            success: function (res) {
               if (res.cancel) {
               } else {
                  //点击确定
                  t.default.getReq(e, function(resdata) {
                    if(resdata.code==0){
                        wx.showToast({
                          title: '删除成功',
                        })
                        n.getlist()
                    }
                    //    console.log(res)
                });
                  
               }
            },
            fail: function (res) { },//接口调用失败的回调函数
            complete: function (res) { },//接口调用结束的回调函数（调用成功、失败都会执行）
         })        
    },
    getlist: function() {
        var n = this, o = "/AppletEquipment/GetList?search=" + this.data.search;
        t.default.getReq(o, function(t) {
            0 == t.code && n.setData({
                list: t.list,
                totalCount: t.totalCount,
                onlineCount: t.onlineCount
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});