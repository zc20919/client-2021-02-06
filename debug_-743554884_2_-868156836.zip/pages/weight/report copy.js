var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        startdate: null,
        enddate: null,
        pageIndex: 1,
        pageSize: 10,
        id: "",
        list: {},
        content: ""
    },
    bindDateChange: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            startdate: t.detail.value
        });
    },
    bindDateChange1: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            enddate: t.detail.value
        });
    },
    onLoad: function(t) {
 
        this.setData({
            id: t.id
        });
        t.id;
        this.getlist(t.id);
    },
    getlist: function(e) {
        var a = this, n = "/NetWeightQuery/GetStatisticalReport?Id=" + e + "&beginTime=" + (null != this.data.startdate ? this.data.startdate : "") + "&endTime=" + (null != this.data.enddate ? this.data.enddate : "") + "&pageIndex=" + this.data.pageIndex + "&pageSize=" + this.data.pageSize;
        t.default.getReq(n, function(t) {
            0 == t.code && a.setData({
                list: t.model,
                content: t.content
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    searchlist: function() {
        console.log(1), this.setData({
            list: [],
            pageIndex: 1
        }), this.getlist(this.data.id);
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});