var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));
import {getnowtime,formatTime} from '../../utils/util'
Page({
    data: {
        currentDate:new Date().getTime(),
        show:false,
        starttime:null,
        show1:null,
        starttime1:null,
        maxdate1:'',
        maxdate:'',
        startdate: null,
        enddate: null,
        pageIndex: 1,
        pageSize: 10,
        id: "",
        list: [],
        totalCarCount: "",
        totalWeightCount: "",
        companyName:'',
        carNumber:'',
        hairCompany:'',
        collectCompany:'',
        goodsName:'',
        formatter(type, value) {
            // console.log(type)
            if (type === 'year') {
              return `${value}年`;
            } else if (type === 'month') {
              return `${value}月`;
            } else if (type === 'year') {
                return `${value}日`;
              } else if (type === 'hour') {
                return `${value}时`;
              } else if (type === 'minute') {
                return `${value}分`;
              }
            return value;
          },
    },
    bindDateChange: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            startdate: t.detail.value
        });
    },
    changekey(e){
        console.log(e.currentTarget.dataset.key,e.detail.value)
        this.setData({
            [e.currentTarget.dataset.key]:e.detail.value
        })
    },
    bindDateChange1: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            enddate: t.detail.value
        });
    },
    //选择日企时间
    onInput(event){
       
        
    },
    showstart(){
        console.log(123)
        this.setData({
            show:true,
        })
    },
    onClose(){
        this.setData({
            show:false,
            show1:false,
        })
    },
    suremaxdate(event){
        // console.log(event)
        this.setData({
            maxdate:event.detail,
            show:false,
            starttime:formatTime(new Date(event.detail))
        })
    },
    suremaxdate1(event){
        // console.log(event)
        this.setData({
            maxdate1:event.detail,
            show1:false,
            starttime1:formatTime(new Date(event.detail))
        })
    },
    showstart1(){
        this.setData({
            show1:true,
        })
    },
    suremaxdate(event){
        // console.log(event)
        this.setData({
            maxdate:event.detail,
            show:false,
            starttime:formatTime(new Date(event.detail))
        })
    },
    onLoad: function(t) {
        // console.log(new Date().toLocaleDateString())
        // console.log(new Date(new Date().getTime()+86400000).toLocaleDateString())
        console.log(formatTime(new Date()),formatTime(new Date(new Date().getTime()+86400000)))
        let data=getnowtime()
        
        this.setData({
            startnow:formatTime(new Date(new Date().toLocaleDateString()+' 00:00:00')),
            nextnow:formatTime(new Date(new Date(new Date().getTime()+86400000).toLocaleDateString()+' 00:00:00')),
            maxdate: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime(),
            maxdate1: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime()
        })
        // console.log(data.split('/').join('-').toString()+' 00:00:00')
        this.setData({
            id: t.id
        });
        t.id;
        this.getlist(t.id);
    },
    getlist: function(e) {
        var a = this, 
        i = "/NetWeightQuery/GetWeighingHistory?Id=" 
        + e + "&beginTime=" + (null != this.data.starttime ? this.data.starttime : this.data.startnow)
         + "&endTime=" + (null != this.data.starttime1 ? this.data.starttime1 :  this.data.nextnow) 
         + "&pageIndex=" + this.data.pageIndex + "&pageSize=" + this.data.pageSize
         + "&carNumber=" + this.data.carNumber+ "&hairCompany=" + this.data.goodsName
         + "&goodsName=" + this.data.companyName+ "&collectCompany=" + this.data.collectCompany;
        t.default.getReq(i, function(t) {
            console.log(t), 0 == t.code && a.setData({
                pageIndex: a.data.pageIndex + 1,
                list: a.data.list.concat(t.list),
                totalCarCount: t.totalCarCount,
                totalWeightCount: t.totalWeightCount
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    searchlist: function() {
        console.log(1), this.setData({
            list: [],
            pageIndex: 1
        }), this.getlist(this.data.id);
    },
    onReachBottom: function() {
        this.getlist(this.data.id);
    },
    onShareAppMessage: function() {}
});