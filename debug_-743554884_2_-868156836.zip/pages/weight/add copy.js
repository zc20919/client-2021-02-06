function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        sureresult: [],
        result: [],
        addressName: "",
        latitude: "",
        list: [],
        longitude: "",
        type: 0,
        search: "",
        weightid: "",
        weightname: "",
        show: !1,
        listarr: []
    },
    Select: function(t) {
        this.setData({
            type: t.detail.value
        });
    },
    onChange: function(t) {
        this.setData({
            result: t.detail
        });
    },
    onChangeinp: function() {
        var t = this, a = "/AppletCamera/GetList?search=" + this.data.search;
        e.default.getReq(a, function(e) {
            0 == e.code && t.setData({
                list: e.list
            });
        });
    },
    bindKeyInput: function(e) {
        console.log(e), this.setData(t({}, e.currentTarget.dataset.key, e.detail.value));
    },
    showPopuplist: function() {
        this.setData({
            show: !0
        });
    },
    onClose: function() {
        var t = this.data.sureresult, e = this.data.list.map(function(e) {
            return -1 != t.indexOf(e.Id.toString()) ? e.checked = !0 : e.checked = !1, e;
        });
        console.log(listarr), this.setData({
            show: !1,
            list: e,
            result: t,
            listarr: listarr
        });
    },
    gosure: function() {
        if (!this.data.weightid) return wx.showToast({
            title: "请输入地磅编号",
            icon: "none"
        }), !1;
        if (!this.data.weightname) return wx.showToast({
            title: "请输入地磅名称",
            icon: "none"
        }), !1;
        if (!this.data.addressName) return wx.showToast({
            title: "请输入地磅地址",
            icon: "none"
        }), !1;
        var t = this.data.result.join(","), a = "/AppletEquipment/Create?Number=" + this.data.weightid + "&Name=" + this.data.weightname + "&Address=" + this.data.addressName + "&AddressMap=" + this.data.longitude + "," + this.data.latitude + "&TypeId=" + this.data.type + "&cameraids=" + t;
        e.default.getReq(a, function(t) {
            console.log(t), 0 == t.code ? (wx.showToast({
                title: t.msg
            }), wx.navigateTo({
                url: "/pages/weight/list"
            })) : wx.showToast({
                title: t.msg
            });
        });
    },
    onLoad: function(t) {},
    sureresult: function() {
        var t = this.data.result, e = this.data.list.filter(function(e) {
            if (console.log(t, e.Id, t.indexOf(e.Id)), -1 != t.indexOf(e.Id.toString())) return e.checked = !0, 
            e;
            e.checked = !1;
        });
        console.log(e), this.setData({
            sureresult: this.data.result,
            show: !1,
            listarr: e
        });
    },
    onReady: function() {},
    choosecity: function() {
        var t = this;
        wx.getLocation({
            type: "gcj02",
            success: function(e) {
                var a = e.latitude, s = e.longitude;
                wx.chooseLocation({
                    latitude: a,
                    longitude: s,
                    success: function(e) {
                        console.log(e), e.address && t.setData({
                            addressName: e.address,
                            latitude: e.latitude,
                            longitude: e.longitude
                        });
                    }
                });
            }
        });
    },
    onShow: function() {
        var t = this, a = "/AppletCamera/GetList?search=" + this.data.search;
        e.default.getReq(a, function(e) {
            console.log(e), t.setData({
                list: e.list
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});