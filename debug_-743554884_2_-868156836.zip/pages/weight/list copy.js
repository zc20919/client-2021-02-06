var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        search: "",
        onlineCount: "",
        totalCount: ""
    },
    goadd: function() {
        wx.navigateTo({
            url: "/pages/weight/add"
        });
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getlist();
    },
    getlist: function() {
        var n = this, o = "/AppletEquipment/GetList?search=" + this.data.search;
        t.default.getReq(o, function(t) {
            0 == t.code && n.setData({
                list: t.list,
                totalCount: t.totalCount,
                onlineCount: t.onlineCount
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});