var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        list: [ {
            url: "/pages/sale/sale",
            txt: "售后服务",
            iconurl: "/images/shouhou.png"
        }, {
            url: "/pages/weight/history",
            txt: "称重历史",
            iconurl: "/images/weighthistory.png"
        }, {
            url: "/pages/weight/report",
            txt: "统计报表",
            iconurl: "/images/tongji.png"
        } ],
        cameralist: [],
        jingzhong: "",
        pizhong: "",
        time: "",
        todayCount: "",
        id: ""
    },
    onLoad: function(n) {
        var e = this;
        this.setData({
            id: n.id
        });
        var o = "/NetWeightQuery/Index?openId=" + wx.getStorageSync("user").openId + "&Id=" + n.id;
        t.default.getReq(o, function(t) {
            0 == t.code && e.setData({
                cameralist: t.cameralist,
                jingzhong: t.jingzhong,
                pizhong: t.pizhong,
                time: t.time,
                todayCount: t.todayCount
            });
        });
    },
    gonav1: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    gonav: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url + "?id=" + this.data.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});