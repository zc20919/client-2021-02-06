function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}
import {getnowtime,formatTime} from '../../utils/util'

// import {getnowtime} from "../../utils/util";
var e, a = function (t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page((e = {
    data: {
        currentDate:new Date().getTime(),
        startdate: null,
        enddate: null,
        pageIndex: 1,
        pageSize: 10,
        show:false,
        search:'',
        starttime:null,
        show1:null,
        starttime1:null,
        maxdate1:'',
        maxdate:'',
        list: [],
        maxdate:'',
        formatter(type, value) {
            // console.log(type)
            if (type === 'year') {
              return `${value}年`;
            } else if (type === 'month') {
              return `${value}月`;
            } else if (type === 'year') {
                return `${value}日`;
              } else if (type === 'hour') {
                return `${value}时`;
              } else if (type === 'minute') {
                return `${value}分`;
              }
            return value;
          },
    },
    bindDateChange: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            startdate: t.detail.value
        });
    },
    bindKeyInput(t){
        this.setData({
            search: t.detail.value
        })
    },
    bindDateChange1: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            enddate: t.detail.value
        });
    },
        //选择日企时间
        onInput(event){
       
        
        },
        showstart(){
            this.setData({
                show:true,
            })
        },
        onClose(){
            this.setData({
                show:false,
                show1:false,
            })
        },
        searchlist(){
            this.setData({
                list:[],
                pageIndex:1
            });
            this.getlist()

        },
        suremaxdate(event){
            // console.log(event)
            this.setData({
                maxdate:event.detail,
                show:false,
                starttime:formatTime(new Date(event.detail))
            })
        },
        suremaxdate1(event){
            // console.log(event)
            this.setData({
                maxdate1:event.detail,
                show1:false,
                starttime1:formatTime(new Date(event.detail))
            })
        },
        showstart1(){
            this.setData({
                show1:true,
            })
        },
        suremaxdate(event){
            // console.log(event)
            this.setData({
                maxdate:event.detail,
                show:false,
                starttime:formatTime(new Date(event.detail))
            })
        },
    bindDateChange: function (t) {
        console.log(t)
        this.setData({
            startdate: t.detail.value
        });
    }
}, t(e, "bindDateChange1", function (t) {
    this.setData({
        enddate: t.detail.value
    });
}), t(e, "getlist", function () {
    var t = this, e = "/AppletMyCenter/GetWeighingHistory?OpenId=" + wx.getStorageSync("user").openId + "&beginTime=" + (null != this.data.starttime ? this.data.starttime : "") + "&endTime=" + (null != this.data.starttime1 ? this.data.starttime1 : "") + "&pageIndex=" + this.data.pageIndex + "&pageSize=" + this.data.pageSize+"&search="+this.data.search;
    a.default.getReq(e, function (e) {
        0 == e.code && t.setData({
            list: t.data.list.concat(e.list),
            pageIndex: t.data.pageIndex + 1
        });
    });
}), t(e, "onLoad", function (t) {
    let data=getnowtime()
        
    this.setData({
        maxdate: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime(),
        maxdate1: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime()
    })
    this.getlist();
}), t(e, "onReady", function () { }), t(e, "onShow", function () { }), t(e, "onHide", function () { }),
    t(e, "onUnload", function () { }), t(e, "onPullDownRefresh", function () { }), t(e, "onReachBottom", function () {
        this.getlist();
    }), t(e, "onShareAppMessage", function () { }), e));