var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));
import {getnowtime,formatTime} from '../../utils/util'

// import {getnowtime} from "../../utils/util";
Page({
    data: {
        currentDate:new Date().getTime(),

        startdate: null,
        enddate: null,
        pageIndex: 1,
        pageSize: 10,
        id: "",
        show:false,
        starttime:null,
        show1:null,
        starttime1:null,
        maxdate1:'',
        maxdate:'',
        list: {},
        content: "",
        maxdate:'',
        formatter(type, value) {
            // console.log(type)
            if (type === 'year') {
              return `${value}年`;
            } else if (type === 'month') {
              return `${value}月`;
            } else if (type === 'year') {
                return `${value}日`;
              } else if (type === 'hour') {
                return `${value}时`;
              } else if (type === 'minute') {
                return `${value}分`;
              }
            return value;
          },
    },
    bindDateChange: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            startdate: t.detail.value
        });
    },
    bindDateChange1: function(t) {
        console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
            enddate: t.detail.value
        });
    },
        //选择日企时间
        onInput(event){
       
        
        },
        showstart(){
            this.setData({
                show:true,
            })
        },
        onClose(){
            this.setData({
                show:false,
                show1:false,
            })
        },
        suremaxdate(event){
            // console.log(event)
            this.setData({
                maxdate:event.detail,
                show:false,
                starttime:formatTime(new Date(event.detail))
            })
        },
        suremaxdate1(event){
            // console.log(event)
            this.setData({
                maxdate1:event.detail,
                show1:false,
                starttime1:formatTime(new Date(event.detail))
            })
        },
        showstart1(){
            this.setData({
                show1:true,
            })
        },
        suremaxdate(event){
            // console.log(event)
            this.setData({
                maxdate:event.detail,
                show:false,
                starttime:formatTime(new Date(event.detail))
            })
        },
    onLoad: function(t) {
        let data=getnowtime()
        
        this.setData({
            maxdate: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime(),
            maxdate1: new Date(data.split('/').join('-').toString()+' 00:00:00').getTime()
        })
        // let data=getnowtime()
        // console.log(data.split('/').join('-').toString())
        //     this.setData({
        //         maxdate: data.split('/').join('-').toString()
        //     })
        this.setData({
            id: t.id
        });
        t.id;
        this.getlist(t.id);
    },
    getlist: function(e) {
        var a = this, n = "/NetWeightQuery/GetStatisticalReport?Id=" + e + "&beginTime=" + (null != this.data.starttime ? this.data.starttime : "") + "&endTime=" + (null != this.data.starttime1 ? this.data.starttime1 : "") + "&pageIndex=" + this.data.pageIndex + "&pageSize=" + this.data.pageSize;
        t.default.getReq(n, function(t) {
            0 == t.code && a.setData({
                list: t.model,
                content: t.content
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    searchlist: function() {
        console.log(1), this.setData({
            list: [],
            pageIndex: 1
        }), this.getlist(this.data.id);
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});