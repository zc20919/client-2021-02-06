function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var e, a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page((e = {
    data: {
        startdate: null,
        enddate: null,
        pageIndex: 1,
        pageSize: 10,
        list: []
    },
    bindDateChange1: function(t) {
        this.setData({
            startdate: t.detail.value
        });
    }
}, t(e, "bindDateChange1", function(t) {
    this.setData({
        enddate: t.detail.value
    });
}), t(e, "getlist", function() {
    var t = this, e = "/AppletMyCenter/GetWeighingHistory?OpenId=" + wx.getStorageSync("user").openId + "&beginTime=" + (null != this.data.startdate ? this.data.startdate : "") + "&endTime=" + (null != this.data.enddate ? this.data.enddate : "") + "&pageIndex=" + this.data.pageIndex + "&pageSize=" + this.data.pageSize;
    a.default.getReq(e, function(e) {
        0 == e.code && t.setData({
            list: t.data.list.concat(e.list),
            pageIndex: t.data.pageIndex + 1
        });
    });
}), t(e, "onLoad", function(t) {
    this.getlist();
}), t(e, "onReady", function() {}), t(e, "onShow", function() {}), t(e, "onHide", function() {}), 
t(e, "onUnload", function() {}), t(e, "onPullDownRefresh", function() {
    this.getlist();
}), t(e, "onReachBottom", function() {}), t(e, "onShareAppMessage", function() {}), 
e));