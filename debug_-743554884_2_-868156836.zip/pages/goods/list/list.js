var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/http"));

Page({
    data: {
        goodsName: "",
        totalCount: "",
        shelfCount: "",
        list: []
    },
    onLoad: function(t) {},
    onReady: function() {},
    goadd: function() {
        wx.navigateTo({
            url: "/pages/goods/add/add"
        });
    },
    onShow: function() {
        this.getlist();
    },
    getlist: function() {
        var e = this, n = "/AppletGoods/Manage?goodsName=" + this.data.goodsName;
        t.default.getReq(n, function(t) {
            e.setData({
                totalCount: t.totalCount,
                shelfCount: t.totalCount,
                list: t.list
            });
        });
    },
    edit: function(t) {
        wx.navigateTo({
            url: "/pages/goods/add/add?id=" + t.currentTarget.dataset.id
        });
    },
    delete: function(e) {
        var n = this;
        wx.showModal({
            title: "删除商品",
            content: "确定要删除该商品？",
            showCancel: !0,
            cancelText: "否",
            confirmText: "是",
            success: function(o) {
                if (o.cancel) ; else {
                    e.currentTarget.dataset.id;
                    var a = "/AppletGoods/Delete?Id=" + e.currentTarget.dataset.id;
                    t.default.getReq(a, function(t) {
                        wx.showToast({
                            title: t.msg
                        });
                        var o = n.data.list.filter(function(t) {
                            if (t.Id != e.currentTarget.dataset.id) return t;
                        });
                        n.setData({
                            list: o
                        });
                    });
                }
            },
            fail: function(t) {},
            complete: function(t) {}
        });
    },
    switch1Change: function(e) {
        var n = "/AppletGoods/Operation?Id=" + e.currentTarget.dataset.id;
        t.default.getReq(n, function(t) {
            console.log(t);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});