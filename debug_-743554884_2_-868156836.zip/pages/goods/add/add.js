var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/http"));

Page({
    data: {
        weightid: "",
        price: "",
        num: "",
        type: 0,
        name: "",
        txt: "",
        IsDisplay: 0,
        fileList1: [],
        fileList: []
    },
    onLoad: function(e) {
        var o = this;
        if (e.id) {
            var i = "/AppletGoods/Details?goodsId=" + e.id;
            t.default.getReq(i, function(t) {
                if (console.log(t), 0 == t.code) {
                    console.log(t.model.GoodsBanner);
                    var e = t.model.GoodsDetails.map(function(t) {
                        return {
                            url: t
                        };
                    }), i = t.model.GoodsBanner.map(function(t) {
                        return {
                            url: t
                        };
                    });
                    console.log(i), o.setData({
                        price: t.model.GoodsPrice,
                        num: t.model.GoodsStock,
                        type: t.model.Id,
                        name: t.model.GoodsName,
                        fileList: i,
                        fileList1: e,
                        txt: t.model.Remark
                    });
                }
            });
        }
    },
    bindKeyInput(e){
        // console.log(e)
        this.setData({
            [e.currentTarget.dataset.key]:e.detail.value
        })
    },
    changeinp: function(t) {
        console.log(t), this.setData({
            txt: t.detail.value
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    delete: function(t) {
        console.log(t);
        var e = this.data.fileList;
        e.splice(t.detail.index, 1), this.setData({
            fileList: e
        });
    },
    afterRead: function(t) {
        var e = this, o = t.detail.file;
        console.log(o), wx.uploadFile({
            url: "https://weighbridge.wxpaying.com/AppletUploadPic/Index",
            filePath: o.path,
            name: "file",
            formData: {
                user: "test"
            },
            success: function(t) {
                var o = JSON.parse(t.data);
                if (console.log(o), 0 == o.code) {
                    wx.showToast({
                        title: o.msg
                    });
                    var i = e.data.fileList;
                    i.push(o), e.setData({
                        fileList: i
                    });
                }
            }
        });
    },
    delete1: function(t) {
        console.log(t);
        var e = this.data.fileList1;
        e.splice(t.detail.index, 1), this.setData({
            fileList1: e
        });
    },
    gosure: function() {
        this.data.fileList, this.data.fileList1;
        var e = this.data.fileList.map(function(t) {
            return t.url;
        }), o = e.join(","), i = this.data.fileList1.map(function(t) {
            return t.url;
        }), a = i.join(",");
        console.log(this.data)
        if (!e) return wx.showToast({
            title: "请上传轮播图",
            icon: "none"
        }), !1;
        if (!i) return wx.showToast({
            title: "请上传商品详情图",
            icon: "none"
        }), !1;
        if (!this.data.price) return wx.showToast({
            title: "请填写价格",
            icon: "none"
        }), !1;
        if (!this.data.name) return wx.showToast({
            title: "请填写商品名",
            icon: "none"
        }), !1;
        if (!this.data.num) return wx.showToast({
            title: "请填写商品库存",
            icon: "none"
        }), !1;
        if (!this.data.txt) return wx.showToast({
            title: "请填写商品描述",
            icon: "none"
        }), !1;
        var s = "/AppletGoods/Create?Id=" + this.data.type + "&GoodsName=" + this.data.name + "&GoodsPrice=" + this.data.price + "&GoodsStock=" + this.data.num + "&IsDisplay=" + (this.data.IsDisplay ? 0 : 1) + "&Remark=" + this.data.txt + "&GoodsImage=" + o + "&GoodsDetails=" + a;
        t.default.getReq(s, function(t) {
            console.log(t), 0 == t.code ? wx.showToast({
                title: t.msg,
                success: function() {
                    wx.navigateTo({
                        url: "/pages/goods/list/list"
                    });
                }
            }):wx.showToast({
              title: t.msg,
              icon:'none'
            });
        });
    },
    Select: function(t) {
        console.log(t), this.setData({
            IsDisplay: t.detail.value
        });
    },
    afterRead1: function(t) {
        var e = this, o = t.detail.file;
        console.log(o), wx.uploadFile({
            url: "https://weighbridge.wxpaying.com/AppletUploadPic/Index",
            filePath: o.path,
            name: "file",
            formData: {
                user: "test"
            },
            success: function(t) {
                var o = JSON.parse(t.data);
                if (console.log(o), 0 == o.code) {
                    wx.showToast({
                        title: o.msg
                    });
                    var i = e.data.fileList1;
                    i.push(o), e.setData({
                        fileList1: i
                    });
                }
            }
        });
    }
});