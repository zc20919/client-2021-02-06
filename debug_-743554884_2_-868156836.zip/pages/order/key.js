Component({
    properties: {
        type: {
            type: Number,
            default: 1
        },
        show: {
            type: Boolean,
            default: !1
        }
    },
    data: {
        cityKeyword1: "京沪浙苏粤鲁晋冀豫",
        cityKeyword2: "川渝辽吉黑皖鄂湘赣",
        cityKeyword3: "闽陕甘宁蒙津贵云",
        cityKeyword4: "桂琼青新藏港澳台",
        keyNumber: "1234567890",
        wordList1: "QWERTYUIOP",
        wordList2: "ASDFGHJKL",
        wordList3: "ZXCVBNM"
    },
    methods: {
        handleClick: function(e) {
            var t = e.currentTarget.dataset.item, r = e.currentTarget.dataset.type;
            switch (t) {
              case "confirm":
                this.triggerEvent("confirm");
                break;

              case "delete":
                this.triggerEvent("delete");
                break;

              default:
                this.triggerEvent("change", {
                    value: t,
                    type: r
                });
            }
        }
    }
});