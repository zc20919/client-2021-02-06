function e(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page({
    data: {
        form: {
            Id: 0,
            inputType: 1,
            showPlateInput: !1,
            openId: ""
        },
        Spare1: "",
        RegistrationPlate: "",
        CorporateName: "",
        GoodsName: "",
        FormName: "",
        WeighingType: "",
        DriverName: "",
        DriverIDCard: ""
    },
    onLoad: function(a) {
        var i = this;
        if (a.id) {
            this.setData(e({}, "form.Id", a.id));
            var o = "/OnlineOrder/Load?Id=" + a.id;
            t.default.getReq(o, function(e) {
                console.log(e), 0 == e.code && i.setData({
                    RegistrationPlate: e.model.RegistrationPlate,
                    CorporateName: e.model.CorporateName,
                    GoodsName: e.model.GoodsName,
                    FormName: e.model.FormName,
                    WeighingType: e.model.WeighingType,
                    DriverName: e.model.DriverName,
                    DriverIDCard: e.model.DriverIDCard,
                    Spare1: e.model.Spare1
                });
            });
        }
    },
    onReady: function() {},
    onShow: function() {
        this.setData(e({}, "form.openId", wx.getStorageSync("user").openId));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    createorder: function() {
        var e = this;
        console.log(e.data)
        if (!this.data.Spare1) return wx.showToast({
            title: "请填写地磅编号",
            icon:'none'
        }), !1;
        if (!this.data.RegistrationPlate) return wx.showToast({
            title: "请填写登记车牌",
            icon:'none'
        }), !1;
        if (!this.data.CorporateName) return wx.showToast({
            title: "请填写公司名称",
            icon:'none'
        }), !1;
        if (!this.data.GoodsName) return wx.showToast({
            title: "请填写货物名称",
            icon:'none'
        }), !1;
        if (!this.data.FormName) return wx.showToast({
            title: "请填写规格名称",
            icon:'none'
        }), !1;
        if (!this.data.WeighingType) return wx.showToast({
            title: "请填写过磅类型",
            icon:'none'
        }), !1;
        if (!this.data.DriverName) return wx.showToast({
            title: "请填写驾驶人姓名",
            icon:'none'
        }), !1;

        var idcardReg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
        // var cardNo = 336767199903037878
        if(!idcardReg.test(this.data.DriverIDCard)) {
            //  
            wx.showToast({
                title: "请填正确身份证",
                icon:'none'
            })
            return !1
        }
        // if (!this.data.DriverIDCard) return , !1;
       
        var a = this.data;
        console.log(this.data);
        var i = "/OnlineOrder/Create?Id=" + a.form.Id + "&RegistrationPlate=" + a.RegistrationPlate + "&CorporateName=" + a.CorporateName + "&GoodsName=" + a.GoodsName + "&FormName=" + a.FormName + "&WeighingType=" + a.WeighingType + "&DriverName=" + a.DriverName + "&DriverIDCard=" + a.DriverIDCard + "&openId=" + a.form.openId + "&Spare1=" + a.Spare1;
        t.default.getReq(i, function(t) {
            if (console.log(t), 0 == t.code) {
                var a = t.Id ? t.Id : e.data.form.Id;
                wx.redirectTo({
                    url: "/pages/orderdetail/orderdetail?id=" + a
                });
            } else wx.showToast({
                title: t.msg,
                icon:'none'
            });
        });
    },
    godetail: function() {},
    handleClick: function(e) {
        var t = -(e.currentTarget.offsetTop - 150), a = 1;
        /^[\u4e00-\u9fa5]+/.test(this.data.RegistrationPlate) && (a = 2), this.setData({
            translateSpace: t,
            showPlateInput: !0,
            inputType: a
        });
    },
    handlePlateChange: function(e) {
        var t = e.detail.value, a = e.detail.type, i = this.data.RegistrationPlate;
        i += t, 1 == a && this.setData({
            inputType: 2
        }), this.setData({
            RegistrationPlate: i
        });
    },
    handlePlateConfirm: function() {
        if (!this.isCarPlate(this.data.RegistrationPlate)) return wx.showToast({
            title: "请输入正确的车牌号",
            icon: "none",
            duration: 2e3
        }), !1;
        this.setData({
            translateSpace: 0,
            showPlateInput: !1,
            inputType: 1
        });
    },
    handlePlateDelete: function(e) {
        var t = this.data.RegistrationPlate;
        0 == (t = t.substring(0, t.length - 1)).length && this.setData({
            inputType: 1
        }), this.setData({
            RegistrationPlate: t
        });
    },
    isCarPlate: function(e) {
        return /^(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z](([0-9]{5}[DF])|([DF]([A-HJ-NP-Z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳使领]))$/.test(e);
    }
});