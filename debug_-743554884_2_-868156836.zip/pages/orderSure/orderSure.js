var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        value: "",
        num: 1,
        region: [],
        customItem: "全部",
        detail: "",
        name: "",
        phone: "",
        goodsdetail: {},
        issubmit: !0
    },
    bindRegionChange: function(t) {
        this.setData({
            region: t.detail.value
        });
    },
    bindnameInput: function(t) {
        this.setData({
            name: t.detail.value
        });
    },
    bindphoneInput: function(t) {
        this.setData({
            phone: t.detail.value
        });
    },
    binddetailInput: function(t) {
        this.setData({
            detail: t.detail.value
        });
    },
    onLoad: function(e) {
        var a = this;
        t.default.getReq("/AppletOrder/Load?goodsId=" + e.id, function(t) {
            a.setData({
                goodsdetail: t.model
            });
        });
    },
    onChange: function(t) {
       this.setData({
            num: t.detail
        });
        this.setData({
            total: (t.detail*this.data.goodsdetail.GoodsPrice).toFixed(2)
        })
    },
    onReady: function() {},
    godetail: function(e) {
        if ("" == this.data.name) return wx.showToast({
            title: "请填写正确名字",
            icon: "none"
        }), !1;
        if ("" == this.data.phone) return wx.showToast({
            title: "请填写电话",
            icon: "none"
        }), !1;
        if ("" == this.data.region) return wx.showToast({
            title: "请选择地区",
            icon: "none"
        }), !1;
        if ("" == this.data.detail) return wx.showToast({
            title: "请填写详细地址",
            icon: "none"
        }), !1;
        if (this.data.issubmit) {
            var a = this;
            this.setData({
                issubmit: !1
            });
            var n = wx.getStorageSync("user"), i = this.data.goodsdetail, o = this.data.region[0] + this.data.region[1] + this.data.region[2], s = "/AppletOrder/Save?openId=" + n.openId + "&goodsId=" + i.Id + "&goodsCount=" + this.data.num + "&totalMoney=" + this.data.num * i.GoodsPrice + "&addressTel=" + this.data.phone + "&addressName=" + this.data.name + "&addressDetails=" + (o + this.data.detail);
            t.default.getReq(s, function(t) {
                0 == t.code && wx.showToast({
                    title: "提交成功",
                    icon: "success",
                    duration: 2e3,
                    success: function() {
                        console.log("haha"), setTimeout(function() {
                            a.setData({
                                issubmit: !0
                            }), wx.navigateTo({
                                url: e.currentTarget.dataset.url
                            });
                        }, 2e3);
                    }
                });
            });
        }
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});