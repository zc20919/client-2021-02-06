var o = function(o) {
    return o && o.__esModule ? o : {
        default: o
    };
}(require("../../utils/http"));

Page({
    data: {
        form: {},
        Id: "",
        qrcode: ""
    },
    onLoad: function(n) {
        var e = this;
        this.setData({
            Id: n.id
        });
        var t = "/OnlineOrder/Load?Id=" + n.id;
        o.default.getReq(t, function(o) {
            console.log(o), 0 == o.code && e.setData({
                form: o.model,
                qrcode: o.qrcode
            });
        });
    },
    edit: function() {
        wx.redirectTo({
            url: "/pages/order/order?id=" + this.data.Id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});