var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page({
    data: {
        isborder: !1,
        phone: "",
        pwd: "",
        isborder1: !1
    },
    onLoad: function(e) {},
    blurphone: function() {
        this.setData({
            isborder: !1
        });
    },
    changeinp(e){
        // console.log(e.detail.value)
        this.setData({
           [e.currentTarget.dataset.key]:e.detail.value
        })
    },
    login: function() {
        var n = this, o = wx.getStorageSync("user"), t = "/AppletLogin/Index?userName=" + this.data.phone + "&userPwd=" + this.data.pwd + "&openId=" + o.openId + "&unionId=" + o.unionId;
        e.default.getReq(t, function(e) {
            0 == e.code ? (wx.setStorageSync("login", 1), wx.showToast({
                title: "登陆成功",
                icon: "success",
                duration: 2e3,
                success: function() {
                    setTimeout(function() {
                        n.setData({
                            issubmit: !0
                        }), wx.navigateTo({
                            url: "/pages/index/index"
                        });
                    }, 2e3);
                }
            })) : -4 == e.code ? wx.showModal({
                title: "请重新授权",
                showCancel: !0,
                cancelText: "关闭",
                confirmText: "重试",
                success: function(e) {
                    e.confirm ? wx.navigateTo({
                        url: "/pages/home/home"
                    }) : e.cancel;
                }
            }) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        });
    },
    focusphone: function() {
        this.setData({
            isborder: !0
        });
    },
    blurpwd: function() {
        this.setData({
            isborder1: !1
        });
    },
    focuspwd: function() {
        this.setData({
            isborder1: !0
        });
    },
    onReady: function() {},
    onShow: function() {},
    bindGetUserInfo: function(e) {
        wx.setStorageSync("userinfo", e.detail.userInfo), wx.navigateTo({
            url: "/pages/userinfo/userinfo"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    statechange: function(e) {
        console.log("live-player code:", e.detail.code);
    },
    error: function(e) {
        console.error("live-player error:", e.detail.errMsg);
    }
});