var n = function(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}(require("../../utils/http"));

Page({
    data: {
        Id: "",
        url: ""
    },
    onLoad: function(t) {
        var e = this;
        this.setData({
            Id: t.id
        });
        var o = "/AppletCamera/GetLiveAddress?Id=" + t.id;
        n.default.getReq(o, function(n) {
            console.log(n), 200 == n.res.code && e.setData({
                url: n.res.data.rtmp
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});