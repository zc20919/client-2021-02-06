function e(e, t, o) {
    return t in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e;
}

var t, o = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page((t = {
    data: {
        GoodsDetails: "",
        indicatorDots: !1,
        background: [ "https://ns-strategy.cdn.bcebos.com/ns-strategy/upload/fc_big_pic/part-00584-2669.jpg", "https://ns-strategy.cdn.bcebos.com/ns-strategy/upload/fc_big_pic/part-00796-831.jpg", "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4098581778,1587235312&fm=26&gp=0.jpg" ]
    },
    onLoad: function(e) {
        this.getshopdetail(e.id);
    },
    getshopdetail: function(e) {
        var t = this;
        o.default.getReq("/AppletGoods/Details?goodsId=" + e, function(e) {
            console.log(e.code, 12323211), 200 == e.code || 0 == e.code ? t.setData({
                background: e.model.GoodsBanner,
                GoodsDetails: e.model
            }) : wx.showModal({
                title: "删除图片",
                success: function(e) {
                    e.cancel && wx.wx.navigateBack({
                        delta: 1
                    });
                },
                fail: function(e) {},
                complete: function(e) {}
            });
        });
    },
    orderSure: function(e) {},
    onReady: function() {},
    onShow: function() {}
}, e(t, "orderSure", function(e) {
    console.log(e), wx.getStorageSync("user").usermodel && null != wx.getStorageSync("user").usermodel ? wx.redirectTo({
        url: e.currentTarget.dataset.url
    }) : wx.getStorageSync("myuserinfo") ? wx.redirectTo({
        url: e.currentTarget.dataset.url
    }) : wx.navigateTo({
        url: "/pages/home/home"
    });
}), e(t, "onHide", function() {}), e(t, "onUnload", function() {}), e(t, "onPullDownRefresh", function() {}), 
e(t, "onReachBottom", function() {}), e(t, "onShareAppMessage", function() {}), 
t));