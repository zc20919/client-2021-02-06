function e(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page({
    data: {
        maxNumber: 100,
        number: 0,
        openId: "",
        reviewText: "",
        mobile: ""
    },
    inputText: function(e) {
        var t = e.detail.value, n = t.length;
        this.setData({
            number: n,
            reviewText: t
        });
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        var n = this;
        this.setData(e({}, "openId", wx.getStorageSync("user").openId));
        t.default.getReq("/AppletMyCenter/GetPlatformInfo", function(e) {
            console.log(e), 0 == e.code && n.setData({
                mobile: e.mobile
            });
        });
    },
    gomobile: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile,
            success: function(e) {},
            fail: function() {},
            complete: function() {}
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    submitsale: function(e) {
        var n = "/AppletMyCenter/Feedback?typeId=1&openId=" + this.data.openId + "&content=" + this.data.reviewText;
        t.default.getReq(n, function(e) {
            console.log(e), 0 == e.code ? wx.showToast({
                title: "反馈成功",
                duration: 1e3,
                success: function(e) {
                    setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 1e3);
                }
            }) : wx.showToast({
                title: e.msg,
                duration: 1e3
            });
        });
    }
});