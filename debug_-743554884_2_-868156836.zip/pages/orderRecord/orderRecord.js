var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/http"));

Page({
    data: {
        navlist: [ "全部", "已处理", "未处理" ],
        myindx: 0,
        list: []
    },
    onLoad: function(t) {},
    changenav: function(t) {
        this.setData({
            myindx: t.currentTarget.dataset.index
        }), this.getlist();
    },
    onReady: function() {},
    onShow: function() {
        this.getlist();
    },
    getlist: function() {
        var n = this, e = wx.getStorageSync("user").openId, i = void 0;
        i = 0 == this.data.myindx ? -1 : 1 == this.data.myindx ? 1 : 0, t.default.getReq("/AppletOrder/Record?openId=" + e + "&typeId=" + i, function(t) {
            n.setData({
                list: t.list
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});