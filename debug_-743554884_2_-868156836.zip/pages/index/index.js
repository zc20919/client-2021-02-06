var n = function(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}(require("../../utils/http"));

Page({
    data: {
        enter: !1,
        user:{},
        userinfo:{}
    },
    gpnav: function(n) {
        wx.navigateTo({
            url: n.currentTarget.dataset.url
        });
    },
    gpnav2(n){
        if(wx.getStorageSync('userinfo')){
            wx.navigateTo({
                url: n.currentTarget.dataset.url
            });
        }else{
            if(wx.getStorageSync('user').usermodel&&wx.getStorageSync('user').usermodel!=null){
                wx.navigateTo({
                    url: n.currentTarget.dataset.url
                });
            }else{
                wx.navigateTo({
                    url:'/pages/home/home'
                });
            }
        }
    },
    gpnav1(n){
        // console.log(this.data.user)
       let user=!user? wx.getStorageSync('user'):user
       console.log(user)
        if(user.usermodel&&user.usermodel!=null){
            if(user.usermodel.TypeId==0){
                // console.log( )
                wx.showToast({
                  title:this.data.user.msgContent ,
                  icon:'none'
                })
                // wx.showModal({
                //     content:this.data.user.msgContent,
                // })
            }else{
                wx.navigateTo({
                    url: n.currentTarget.dataset.url
                });
            }
           
        }else{
         
            // if(this.data.user.usermodel.TypeId==0){
            //     wx.showModal({
            //       title:this.data.user.usermodel.msgContent,
            //     })
            // }else{
                wx.navigateTo({
                    url:'/pages/home/home'
                });
            // }
           
        }
    },
    onLoad: function(e) {
        var t = this, o = "/AppletHome/Index?OpenId=" + wx.getStorageSync("user").openId;
        n.default.getReq(o, function(n) {
            0 == n.code && t.setData({
                enter: !0
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        var r = this;
        if (wx.getStorageSync("user")) {
            var f = "/AppletMyCenter/Index?openId=" + wx.getStorageSync("user").openId;
            n.default.getReq(f, function(e) {
                0 == e.code && (wx.setStorageSync("user", e), r.setData({
                    user: e,
                    userinfo: e.usermodel
                }));
            });
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    gohome: function() {
        wx.redirectTo({
            url: "/pages/userinfo/userinfo"
        });
    },
    onShareAppMessage: function() {}
});