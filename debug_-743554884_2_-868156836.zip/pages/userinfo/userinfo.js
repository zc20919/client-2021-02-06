function e(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page({
    data: {
        userinfo: {},
        user: {},
        navlist: [{
            url: "/pages/orderRecord/orderRecord",
            img: "/images/yuyueicon.png",
            txt: "预约记录"
        }, {
            url: "/pages/Feedback/Feedback",
            img: "/images/fankui.png",
            txt: "意见反馈"
        } ],
        navlist2: [ {
            url: "/pages/weight/list",
            img: "/images/yuyueicon.png",
            txt: "地磅管理"
        }, {
            url: "/pages/camera/list",
            img: "/images/order.png",
            txt: "摄像头管理"
        }, {
            url: "/pages/customer/list/list",
            img: "/images/fankui.png",
            txt: "客户管理"
        }, {
            url: "/pages/goods/list/list",
            img: "/images/fankui.png",
            txt: "商品管理"
        }, {
            url: "/pages/machine/list/list",
            img: "/images/fankui.png",
            txt: "一体机管理"
        } ],
        navlist1: [ {
            url: "/pages/weight/weight",
            img: "/images/yuyueicon.png",
            txt: "称重记录"
        }, {
            url: "/pages/orderRecord/orderRecord",
            img: "/images/order.png",
            txt: "预约记录"
        }, {
            url: "/pages/customer/list/list",
            img: "/images/fankui.png",
            txt: "客户管理"
        }, {
            url: "/pages/Feedback/Feedback",
            img: "/images/fankui.png",
            txt: "意见反馈"
        } ],
        navlist0: [  {
            url: "/pages/weight/weight",
            img: "/images/yuyueicon.png",
            txt: "称重记录"
        },  {
            url: "/pages/orderlist/orderlist",
            img: "/images/fankui.png",
            txt: "下单列表"
        }, 
      {
            url: "/pages/orderRecord/orderRecord",
            img: "/images/yuyueicon.png",
            txt: "预约记录"
        },  {
            url: "/pages/Feedback/Feedback",
            img: "/images/fankui.png",
            txt: "意见反馈"
        },]
    },
    onLoad: function(e) {},
    gologin: function() {
        wx.redirectTo({
            url: "/pages/home/home"
        });
    },
    zclogin: function() {
        if(wx.getStorageSync("userinfo")){
            wx.redirectTo({
                url: "/pages/userlogin/userlogin"
            }) 
        }else{
            if(wx.getStorageSync("user").usermodel){
                wx.redirectTo({
                    url: "/pages/userlogin/userlogin"
                })
            }else{
                wx.redirectTo({
                    url: "/pages/home/home"
                })
            }
        }
        // wx.getStorageSync("userinfo") ? wx.redirectTo({
        //     url: "/pages/userlogin/userlogin"
        // }) : wx.redirectTo({
        //     url: "/pages/home/home"
        // });
    },
    godetail: function(e) {
        wx.getStorageSync("user").usermodel && null != wx.getStorageSync("user").usermodel ? wx.navigateTo({
            url: e.currentTarget.dataset.url
        }) : wx.getStorageSync("myuserinfo") ? wx.navigateTo({
            url: e.currentTarget.dataset.url
        }) : wx.navigateTo({
            url: "/pages/home/home"
        });
    },
    onReady: function() {},
    onShow: function() {
        var r = this;
        if (wx.getStorageSync("user")) {
            var n = "/AppletMyCenter/Index?openId=" + wx.getStorageSync("user").openId;
            t.default.getReq(n, function(e) {
                0 == e.code && (wx.setStorageSync("user", e), r.setData({
                    user: e,
                    userinfo: e.usermodel
                }));
            });
        }
        this.setData({
            userinfo: wx.getStorageSync("userinfo"),
            user: wx.getStorageSync("user") ? wx.getStorageSync("user").usermodel : {}
        }), wx.getStorageSync("user").usermodel && (wx.getStorageSync("user").usermodel.TypeId && this.setData(e({}, "navlist", this.data["navlist" + wx.getStorageSync("user").usermodel.TypeId])), 
        0 == wx.getStorageSync("user").usermodel.TypeId && this.setData(e({}, "navlist", this.data["navlist" + wx.getStorageSync("user").usermodel.TypeId])));
    },
    onHide: function() {},
    gohome: function() {
        wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});