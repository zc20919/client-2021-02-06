var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/http"));

Page({
    data: {},
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    dohome: function() {
        wx.navigateTo({
            url: "/pages/index/index"
        });
    },
    bindGetUserInfo: function(n) {
        var o = n.detail.userInfo, t = wx.getStorageSync("user"), a = wx.getStorageSync("code");
        wx.getUserInfo({
            success: function(n) {
                console.log(n);
                var i = "/AppletOAuthcenter/CreateUser?typeId=1&&nickName=" + o.nickName + "&&hendPic=" + o.avatarUrl + "&&openId=" + t.openId + "&&unionId=" + t.unionId + "&&encryptedData=" + n.encryptedData + "&&iv=" + n.iv + "&&code=" + a;
                e.default.getReq(i, function(e) {
                    wx.setStorageSync("userinfo", o), wx.setStorageSync("myuserinfo", e), "-2" == e.code ? wx.navigateTo({
                        url: "/pages/index/index"
                    }) : 0 == e.code ? wx.navigateTo({
                        url: "/pages/index/index"
                    }) : wx.showToast({
                        title: e.msg
                    });
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    statechange: function(e) {
        console.log("live-player code:", e.detail.code);
    },
    error: function(e) {
        console.error("live-player error:", e.detail.errMsg);
    }
});