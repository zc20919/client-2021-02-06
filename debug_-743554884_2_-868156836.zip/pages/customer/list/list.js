var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/http"));

Page({
    data: {
        list: [],
        shelfCount: "",
        totalCount: "",
        search: "",
        typelist: [ "客户", "用户", "管理" ]
    },
    goadd: function() {
        wx.navigateTo({
            url: "/pages/customer/add/add"
        });
    },
    del(e){
        var n = this, e = "/Delete/Index?TypeId=3&Id=" +e.currentTarget.dataset.id;
        wx.showModal({
            title: '是否删除',
            content: '请确认删除客户',
            cancelText:"否",//默认是“取消”
            confirmText:"是",//默认是“确定”
            success: function (res) {
               if (res.cancel) {
               } else {
                  //点击确定
                  t.default.getReq(e, function(resdata) {
                    if(resdata.code==0){
                        wx.showToast({
                          title: '删除成功',
                        })
                        n.getlist()
                    }
                    //    console.log(res)
                });
                  
               }
            },
            fail: function (res) { },//接口调用失败的回调函数
            complete: function (res) { },//接口调用结束的回调函数（调用成功、失败都会执行）
         })
        // console.log(e.currentTarget.dataset.id)
    
    
        // /API/Delete/Index?TypeId=(1地磅管理,2摄像头,3客户,4商品,5一体机)&Id=
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getlist();
    },
    getlist: function() {
        var n = this, o = "/AppletUser/GetList?searchName=" + this.data.search+"&openId="+wx.getStorageSync('user').openId+"&typeId="+wx.getStorageSync('user').usermodel.TypeId;
        t.default.getReq(o, function(t) {
            0 == t.code && n.setData({
                list: t.list,
                totalCount: t.totalCount,
                useCount: t.useCount
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});