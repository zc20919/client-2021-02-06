var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/http"));

Page({
    data: {
        sureresult: [],
        result: [],
        list: [],
        accont: "",
        psd: "",
        company: "",
        name: "",
        phone: "",
        listarr: [],
        show: !1,
        searchbox: "",
        IsDisplay: 0,
        typeid: ""
    },
    showpopu: function() {
        this.setData({
            show: !0
        });
    },
    Selectself: function(t) {
        console.log(t)
        this.setData({
            IsDisplay: t.detail.value
        });
    },
    Select: function(t) {
        this.setData({
            type: t.detail.value
        });
    },
    sureresult: function() {
        var t = this.data.result, e = this.data.list.filter(function(e) {
            if (console.log(t, e.Id, t.indexOf(e.Id)), -1 != t.indexOf(e.Id.toString())) return e.checked = !0, 
            e;
            e.checked = !1;
        });
        this.setData({
            sureresult: this.data.result,
            show: !1,
            listarr: e
        });
    },
    onClose: function() {
        var t = this.data.sureresult, e = this.data.list.map(function(e) {
            return -1 != t.indexOf(e.Id.toString()) ? e.checked = !0 : e.checked = !1, e;
        });
        console.log(e), this.setData({
            show: !1,
            list: e,
            result: t
        });
    },
    onChange: function(t) {
        this.setData({
            result: t.detail
        });
    },
    getlist: function() {
        var e = this, n = "/AppletEquipment/GetList?search=" + this.data.searchbox;
        t.default.getReq(n, function(t) {
            0 == t.code && e.setData({
                list: t.list
            });
        });
    },
    onChangeinp: function() {
        this.getlist();
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getlist(), this.setData({
            typeid: wx.getStorageSync("user").usermodel.TypeId
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    addsub: function() {
        console.log(this.data.result);
        var e = this.data.sureresult.join(","), n = this.data;
        
        console.log(n)
      
        var telStr = /^[1]([3-9])[0-9]{9}$/;

        if (!(telStr.test(n.phone))) return wx.showToast({
            title: "请填写正确手机",
            icon: "none"
        }), !1;
        // if (!n.accont) return wx.showToast({
        //     title: "请填写账号",
        //     icon: "none"
        // }), !1;
        if (!n.psd) return wx.showToast({
            title: "请填写密码",
            icon: "none"
        }), !1;
        if (!n.company) return wx.showToast({
            title: "请填写公司",
            icon: "none"
        }), !1;
        if (!n.name) return wx.showToast({
            title: "请填写姓名",
            icon: "none"
        }), !1;
        
        console.log(n.typeid)
        if(n.IsDisplay==1){
            if (!e) return wx.showToast({
                title: "请添加地磅",
                icon: "none"
            }), !1;
        }
        
        var o = wx.getStorageSync("user").openId, s = wx.getStorageSync("user").usermodel.TypeId, i = "/AppletUser/Create?Mobile=" + n.phone + "&LoginPwd=" + n.psd + "&CompanyName=" + n.company + "&UserName=" + n.name + "&OpenId=" + o  + "&wid=" + e + "&TypeId=" + n.IsDisplay;
        t.default.getReq(i, function(t) {
            console.log(t), 0 == t.code ? (wx.showToast({
                title: t.msg
            }), wx.navigateBack({
                delta: 1
            })) : wx.showToast({
                title: t.msg,
                icon:'none'
            });
        });
    }
});