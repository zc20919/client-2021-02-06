module.exports = {
    BASE_URL: "https://weighbridge.wxpaying.com"
};